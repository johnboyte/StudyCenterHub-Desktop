<?php
/**
 * index.php
 * Unified PHP router, controllers, and database buffer for the StudyCenterHub Cloud Relay.
 * Complies with minimal durable relay architecture guidelines: zero business logic, zero caller matching.
 */

// Enable error logging, disable direct error output in production
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header("Content-Type: application/json; charset=utf-8");

// Setup SQLite path structure
$db_path = __DIR__ . '/database/relay.db';
$data_dir = dirname($db_path);
if (!file_exists($data_dir)) {
    mkdir($data_dir, 0777, true);
}

// Connect to SQLite operational event queue buffer
try {
    $db = new SQLite3($db_path);
    $db->exec("PRAGMA journal_mode = WAL;");
    $db->exec("CREATE TABLE IF NOT EXISTS inbound_event_queue (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type TEXT NOT NULL,
        provider_event_id TEXT UNIQUE,
        payload_json TEXT NOT NULL,
        received_at TEXT NOT NULL DEFAULT (datetime('now'))
    );");
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Database connection failed."]);
    exit;
}

// Request path parsing
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$method = $_SERVER['REQUEST_METHOD'];

// Helper to return Twilio TwiML Voice responses
function send_twiml($body) {
    header("Content-Type: text/xml; charset=utf-8");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response>$body</Response>";
    exit;
}

// Helper to enforce security key checking
function verify_api_key() {
    $config_file = __DIR__ . '/config.php';
    $config = file_exists($config_file) ? include($config_file) : [];
    $expected = $config['SYNC_API_KEY'] ?? getenv('SYNC_API_KEY') ?? '';
    
    // Enforce configured key (block fallback if empty or default in production)
    if (empty($expected) || $expected === 'your_secure_api_key_here' || $expected === 'demo_sync_key') {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Sync API Key is not configured on the server."]);
        exit;
    }

    $provided = $_SERVER['HTTP_X_SYNC_API_KEY'] ?? $_GET['sync_api_key'] ?? '';
    if ($provided !== $expected) {
        http_response_code(401);
        echo json_encode(["success" => false, "message" => "Invalid or missing sync API key."]);
        exit;
    }
}

// Route Mappings
if (strpos($uri, '/api/v1/health') !== false || strpos($uri, '/health') !== false) {
    echo json_encode([
        "status" => "ok",
        "database" => "connected",
        "timestamp" => gmdate("Y-m-d H:i:s") . " UTC"
    ]);
    exit;
} else if (strpos($uri, '/api/v1/sync/pull') !== false) {
    // 1. Pull Endpoint: Returns all buffered events in the self-clearing buffer queue
    verify_api_key();
    
    $stmt = $db->prepare("SELECT * FROM inbound_event_queue ORDER BY id ASC;");
    $result = $stmt->execute();
    
    $events = [];
    while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
        $events[] = [
            "id" => $row['id'],
            "event_type" => $row['event_type'],
            "provider_event_id" => $row['provider_event_id'],
            "payload_json" => $row['payload_json'],
            "received_at" => $row['received_at']
        ];
    }
    
    echo json_encode(["success" => true, "events" => $events]);
    exit;

} else if (strpos($uri, '/api/v1/sync/ack') !== false) {
    // 2. Acknowledge Endpoint: Deletes successfully processed event IDs
    verify_api_key();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $event_ids = $input['event_ids'] ?? [];
    $deleted_count = 0;
    
    if (is_array($event_ids) && count($event_ids) > 0) {
        $placeholders = implode(',', array_fill(0, count($event_ids), '?'));
        $stmt = $db->prepare("DELETE FROM inbound_event_queue WHERE id IN ($placeholders);");
        
        for ($i = 0; $i < count($event_ids); $i++) {
            $stmt->bindValue($i + 1, $event_ids[$i], SQLITE3_INTEGER);
        }
        
        $stmt->execute();
        $deleted_count = $db->changes();
    }
    
    echo json_encode(["success" => true, "deleted_count" => $deleted_count]);
    exit;

} else if (strpos($uri, '/api/v1/sync/ivr-config') !== false) {
    // 3. IVR Settings Endpoint: Caches active configuration published by the client
    verify_api_key();
    
    $input = json_decode(file_get_contents('php://input'), true);
    $ivr_config = $input['ivr_config'] ?? null;
    
    if (!$ivr_config) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Invalid or empty ivr_config object."]);
        exit;
    }
    
    file_put_contents($data_dir . '/ivr_config.json', json_encode($ivr_config, JSON_PRETTY_PRINT));
    echo json_encode(["success" => true, "message" => "IVR configuration cached successfully."]);
    exit;

} else if (strpos($uri, '/api/v1/webhooks/twilio/voice-prompt') !== false) {
    // 4. Voice Call Routing: Stateless greeting & dial-forwarding routing
    $config_file = $data_dir . '/ivr_config.json';
    $config = file_exists($config_file) ? json_decode(file_get_contents($config_file), true) : null;
    
    if (!$config) {
        // Fallback default configuration
        $config = [
            "on_call_phone" => "",
            "rollover_rings" => 4,
            "tts_greeting_active" => true,
            "greeting_text" => "Thank you for calling. If you know your extension, please enter it. Press 1 for General Info, or 2 to leave a message.",
            "menu_options" => [
                "1" => ["action_type" => "speak", "script_text" => "We are open Monday through Friday from 3 PM to 8 PM."],
                "2" => ["action_type" => "voicemail", "script_text" => "Please leave your message after the tone."]
            ]
        ];
    }
    
    $digits = trim($_POST['Digits'] ?? $_GET['Digits'] ?? '');
    $parent_digit = trim($_GET['parentDigit'] ?? '');
    $routing_step = trim($_GET['routingStep'] ?? '');

    // Initial Land
    if (!$digits && !$routing_step) {
        if (!empty($config['on_call_phone'])) {
            $timeout = max(5, (intval($config['rollover_rings']) ?: 4) * 5);
            $action = 'https://' . $_SERVER['HTTP_HOST'] . '/api/v1/webhooks/twilio/voice-prompt?routingStep=oncall-completed';
            send_twiml("<Dial timeout=\"$timeout\" action=\"" . htmlspecialchars($action) . "\" method=\"POST\"><Number>" . htmlspecialchars($config['on_call_phone']) . "</Number></Dial>");
        }
        send_twiml_menu($config);
    }
    
    // Rollover Fallout
    if ($routing_step === 'oncall-completed') {
        if (($_POST['DialCallStatus'] ?? '') === 'completed') {
            send_twiml("<Hangup/>");
        }
        send_twiml_menu($config);
    }
    
    // Keypress Actions
    $full_key = $parent_digit ? "$parent_digit-$digits" : $digits;
    $option = $config['menu_options'][$full_key] ?? null;
    
    if (!$option) {
        $action = 'https://' . $_SERVER['HTTP_HOST'] . '/api/v1/webhooks/twilio/voice-prompt';
        send_twiml("<Gather numDigits=\"1\" action=\"" . htmlspecialchars($action) . "\" method=\"POST\" timeout=\"8\"><Say voice=\"alice\">That selection is not valid. Please try again.</Say><Say voice=\"alice\">" . htmlspecialchars($config['greeting_text']) . "</Say></Gather><Hangup/>");
    }
    
    if ($option['action_type'] === 'speak') {
        send_twiml("<Say voice=\"alice\">" . htmlspecialchars($option['script_text']) . "</Say><Hangup/>");
    } else if ($option['action_type'] === 'voicemail') {
        $record = 'https://' . $_SERVER['HTTP_HOST'] . '/api/v1/webhooks/twilio/voicemail';
        send_twiml("<Say voice=\"alice\">" . htmlspecialchars($option['script_text']) . "</Say><Record maxLength=\"120\" action=\"" . htmlspecialchars($record) . "\" method=\"POST\" playBeep=\"true\"/>");
    } else if ($option['action_type'] === 'transfer' && !empty($option['action_param'])) {
        send_twiml("<Say voice=\"alice\">Transferring your call.</Say><Dial><Number>" . htmlspecialchars($option['action_param']) . "</Number></Dial>");
    }
    send_twiml("<Hangup/>");

} else if (strpos($uri, '/api/v1/webhooks/twilio/voicemail') !== false) {
    // 5. Voicemail Ingest Webhook
    $payload = $_POST;
    $provider_event_id = $payload['CallSid'] ?? null;
    
    $stmt = $db->prepare("INSERT OR IGNORE INTO inbound_event_queue (event_type, provider_event_id, payload_json) VALUES ('twilio.voicemail', ?, ?);");
    $stmt->bindValue(1, $provider_event_id, SQLITE3_TEXT);
    $stmt->bindValue(2, json_encode($payload), SQLITE3_TEXT);
    $stmt->execute();
    
    send_twiml("<Say voice=\"alice\">Thank you. Your voicemail has been received.</Say><Hangup/>");

} else if (strpos($uri, '/api/v1/webhooks/twilio/sms') !== false) {
    // 6. SMS Ingest Webhook (with immediate compliance keyword autoreply support)
    $payload = $_POST;
    $provider_event_id = $payload['MessageSid'] ?? null;
    $body_text = strtoupper(trim($payload['Body'] ?? ''));
    
    $stmt = $db->prepare("INSERT OR IGNORE INTO inbound_event_queue (event_type, provider_event_id, payload_json) VALUES ('twilio.sms', ?, ?);");
    $stmt->bindValue(1, $provider_event_id, SQLITE3_TEXT);
    $stmt->bindValue(2, json_encode($payload), SQLITE3_TEXT);
    $stmt->execute();

    $opt_out = ['STOP', 'QUIT', 'CANCEL', 'UNSUBSCRIBE'];
    $opt_in = ['START', 'UNSTOP', 'YES'];
    $help = ['HELP', 'INFO'];

    if (in_array($body_text, $opt_out)) {
        send_twiml("<Message>You have successfully been unsubscribed. You will no longer receive messages from this number.</Message>");
    } else if (in_array($body_text, $opt_in)) {
        send_twiml("<Message>You have successfully resubscribed. Message & data rates may apply.</Message>");
    } else if (in_array($body_text, $help)) {
        send_twiml("<Message>This is the automated text line for Real Life Study Center. For assistance or support, please contact us.</Message>");
    }
    
    header("Content-Type: text/xml");
    echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Response></Response>";
    exit;

} else {
    // Default Fallback
    http_response_code(404);
    echo json_encode(["success" => false, "message" => "Route not found."]);
    exit;
}

function send_twiml_menu($config) {
    $action = 'https://' . $_SERVER['HTTP_HOST'] . '/api/v1/webhooks/twilio/voice-prompt';
    send_twiml("<Gather numDigits=\"1\" action=\"" . htmlspecialchars($action) . "\" method=\"POST\" timeout=\"8\"><Say voice=\"alice\">" . htmlspecialchars($config['greeting_text']) . "</Say></Gather><Say voice=\"alice\">We did not receive your input. Goodbye.</Say><Hangup/>");
}

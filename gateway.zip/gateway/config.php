<?php
/**
 * config.php
 * Production settings and keys for the Cloud Relay.
 * PHP files are processed server-side; their source code is never exposed to the public.
 */

return [
    // Define a secure, random key to authenticate communications between the Godot app and this relay
    'SYNC_API_KEY' => 'your_secure_api_key_here'
];

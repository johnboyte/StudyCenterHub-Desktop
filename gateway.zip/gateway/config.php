<?php
return [
    'SYNC_API_KEY' => getenv('SYNC_API_KEY') ?: 'SCH_SYNC_KEY_PLACEHOLDER_8f3d'
];

<?php
return [
    'SYNC_API_KEY' => getenv('SYNC_API_KEY') ?: 'SCH_SYNC_KEY_PLACEHOLDER_8f3d',
    'TWILIO_ACCOUNT_SID' => getenv('TWILIO_ACCOUNT_SID') ?: 'ACda6e4f4d94d7fcb72e0e2dd9f7ee834f',
    'TWILIO_AUTH_TOKEN' => getenv('TWILIO_AUTH_TOKEN') ?: ''
];
